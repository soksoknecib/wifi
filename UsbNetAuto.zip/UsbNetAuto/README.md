# USB Net Otomatik

Samsung J7 Prime'ı USB'ye takınca internet paylaşımını (USB tethering) kendiliğinden açan küçük uygulama.

## APK'yı alma (bilgisayarda, ücretsiz, ~5 dk)

1. https://github.com adresinde hesap aç (yoksa) ve **New repository** ile boş bir depo oluştur (adı: `UsbNetAuto`).
2. Depoda **uploading an existing file** bağlantısına tıkla, bu klasördeki **her şeyi** (`.github` klasörü dahil) sürükle bırak, **Commit changes**'e bas.
   - `.github` gizli klasör olduğu için sürüklerken görünmeyebilir; ZIP'i bilgisayarda açıp içinden seç.
3. Üstte **Actions** sekmesine gir. "APK derle" çalışmaya başlar (2-3 dk). Yeşil tik olunca tıkla.
4. Sayfanın altındaki **Artifacts** bölümünden `UsbNetAuto-apk` dosyasını indir, ZIP'ten `app-debug.apk` çıkar.
5. APK'yı telefona at (kabloyla ya da Bluetooth/Drive ile) ve kur. "Bilinmeyen kaynaklar" izni isterse ver.

## Telefonda kurulum (bir kere)

1. Uygulamayı aç: **USB Net Otomatik**.
2. **"1) Sistem ayarlarını değiştirme iznini ver"** → açılan ekranda uygulamayı aç (izin ver).
3. **"Otomatik mod"** anahtarını aç. Bildirim çubuğunda küçük bir bildirim çıkar, kalması normal.
4. Telefonu Wi-Fi'ye bağla, USB kabloyla bilgisayara tak. Paylaşım kendiliğinden açılmalı (1-2 sn).

Bu kadar. Telefon yeniden başlayınca da otomatik mod kendiliğinden devam eder.

## Yedek yöntem (1. adım işe yaramazsa)

Bazı Samsung yazılımları doğrudan yöntemi reddedebilir. Uygulamadaki durum satırında "reddedildi" gibi bir şey görürsen:

1. **"2) Erişilebilirlik ayarlarını aç"** → **USB Net Otomatik** servisini aç.
2. USB'yi tekrar tak. Uygulama Ayarlar'ın paylaşım ekranını açıp "USB" satırına kendisi dokunur ve geri döner.

Bu servis sadece Ayarlar uygulamasına bakar ve sadece USB takıldıktan sonraki ~15 saniye çalışır.

## Pil kısıtlaması

Samsung bazen arka plandaki uygulamaları uyutur. Telefonda **Ayarlar → Cihaz bakımı → Pil → Uygulama güç yönetimi** (veya "Pil optimizasyonu") bölümünden **USB Net Otomatik**'i "optimize etme / uyutma" listesinden çıkar.

## Notlar

- Android 6.0 - 8.1 (J7 Prime) için yazıldı. Yeni Android sürümlerinde doğrudan yöntem çalışmaz, yedek yöntem denenir.
- Telefonda root gerekmez.
