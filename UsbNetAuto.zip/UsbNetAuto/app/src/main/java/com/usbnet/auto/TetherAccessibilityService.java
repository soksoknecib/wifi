package com.usbnet.auto;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Locale;

/**
 * Yedek yöntem: Ayarlar'daki "USB ile paylaşım" satırını bulup dokunur.
 * Sadece com.android.settings paketine bakar ve sadece begin() çağrıldıktan sonraki 15 saniye boyunca çalışır.
 */
public class TetherAccessibilityService extends AccessibilityService {

    static volatile TetherAccessibilityService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private long activeUntil = 0;
    private boolean loopRunning = false;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Olayları kullanmıyoruz; begin() sonrası kendi döngümüz çalışır.
    }

    @Override
    public void onInterrupt() {
    }

    /** Ayarlar ekranı açılmadan hemen önce çağrılır. */
    void begin() {
        activeUntil = System.currentTimeMillis() + 15000;
        if (!loopRunning) {
            loopRunning = true;
            handler.postDelayed(loop, 900);
        }
    }

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            if (System.currentTimeMillis() > activeUntil) {
                loopRunning = false;
                return;
            }
            boolean done = false;
            try {
                done = tryClick();
            } catch (Throwable ignored) {
            }
            if (done) {
                activeUntil = 0;
                loopRunning = false;
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        performGlobalAction(GLOBAL_ACTION_BACK);
                    }
                }, 1200);
            } else {
                handler.postDelayed(this, 700);
            }
        }
    };

    /** true dönerse iş bitti (dokunuldu ya da zaten açık). */
    private boolean tryClick() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            return false;
        }
        if (root.getPackageName() == null || !"com.android.settings".contentEquals(root.getPackageName())) {
            return false;
        }
        AccessibilityNodeInfo title = findUsbText(root);
        if (title == null) {
            return false;
        }
        // Başlığın bulunduğu tıklanabilir satırı bul
        AccessibilityNodeInfo row = title;
        for (int i = 0; i < 5 && row != null && !row.isClickable(); i++) {
            row = row.getParent();
        }
        if (row == null) {
            return false;
        }
        if (!row.isEnabled()) {
            return false; // USB takılı değilse satır pasif olur, tekrar denenecek
        }
        AccessibilityNodeInfo box = findCheckable(row);
        if (box != null && box.isChecked()) {
            return true; // zaten açık
        }
        if (box != null && box.isClickable() && box.isEnabled()) {
            return box.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        return row.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private AccessibilityNodeInfo findUsbText(AccessibilityNodeInfo node) {
        if (node == null) {
            return null;
        }
        CharSequence t = node.getText();
        if (t != null && t.toString().toLowerCase(Locale.ENGLISH).contains("usb")) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findUsbText(node.getChild(i));
            if (r != null) {
                return r;
            }
        }
        return null;
    }

    private AccessibilityNodeInfo findCheckable(AccessibilityNodeInfo node) {
        if (node == null) {
            return null;
        }
        if (node.isCheckable()) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo r = findCheckable(node.getChild(i));
            if (r != null) {
                return r;
            }
        }
        return null;
    }
}
