package com.usbnet.auto;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Telefon açılınca, otomatik mod açıksa servisi yeniden başlatır. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())
                && TetherHelper.prefs(context).getBoolean(TetherHelper.KEY_AUTO, false)) {
            TetherService.start(context);
        }
    }
}
