package com.usbnet.auto;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.provider.Settings;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** USB internet paylaşımını açmayı dener. Önce doğrudan sistem çağrısı, olmazsa Ayarlar ekranında otomatik dokunma. */
final class TetherHelper {

    static final String PREFS = "usbnet_prefs";
    static final String KEY_AUTO = "auto";
    static final String KEY_LOG = "log";

    private TetherHelper() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void log(Context c, String msg) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        prefs(c).edit().putString(KEY_LOG, t + "  " + msg).apply();
    }

    /** USB internet paylaşımını açmayı dener, sonucu açıklayan kısa bir metin döndürür. */
    static String enable(Context c) {
        // Yöntem 1: ConnectivityManager.setUsbTethering(true) (gizli API, "Sistem ayarlarını değiştir" izni ister)
        String reason;
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Method m = ConnectivityManager.class.getMethod("setUsbTethering", boolean.class);
            Object r = m.invoke(cm, true);
            if (r == null || (r instanceof Integer && ((Integer) r) == 0)) {
                String ok = "USB paylaşımı açıldı (doğrudan yöntem)";
                log(c, ok);
                return ok;
            }
            reason = "doğrudan yöntem hata kodu döndürdü: " + r;
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            reason = "doğrudan yöntem reddedildi (" + cause.getClass().getSimpleName() + ")";
        } catch (Throwable t) {
            reason = "doğrudan yöntem yok (" + t.getClass().getSimpleName() + ")";
        }

        // Yöntem 2: Ayarlar ekranını aç, erişilebilirlik servisi düğmeye dokunsun
        TetherAccessibilityService acc = TetherAccessibilityService.instance;
        if (acc == null) {
            String msg = reason + "; erişilebilirlik servisi kapalı, yedek yöntem çalışamadı";
            log(c, msg);
            return msg;
        }
        acc.begin();
        if (openTetherSettings(c)) {
            String msg = reason + "; Ayarlar'dan otomatik açılıyor";
            log(c, msg);
            return msg;
        }
        String msg = reason + "; paylaşım ayarı ekranı açılamadı";
        log(c, msg);
        return msg;
    }

    private static boolean openTetherSettings(Context c) {
        String[][] candidates = {
                {"com.android.settings", "com.android.settings.Settings$TetherSettingsActivity"},
                {"com.android.settings", "com.android.settings.TetherSettings"},
        };
        for (String[] cand : candidates) {
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(cand[0], cand[1]));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
                return true;
            } catch (Throwable ignored) {
                // sıradaki adayı dene
            }
        }
        try {
            Intent i = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
