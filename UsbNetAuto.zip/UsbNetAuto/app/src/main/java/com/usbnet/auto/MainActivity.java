package com.usbnet.auto;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView status;
    private Switch autoSwitch;
    private boolean updating = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("USB Net Otomatik");
        title.setTextSize(24);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Telefonu Wi-Fi'ye bağla, USB kabloyla bilgisayara tak: internet paylaşımı kendiliğinden açılır.\n\n"
                + "Kurulum (bir kere):\n"
                + "1) Aşağıdan \"Sistem ayarlarını değiştirme\" iznini ver.\n"
                + "2) (Yedek yöntem için) Erişilebilirlik'ten \"USB Net Otomatik\" servisini aç.\n"
                + "3) Otomatik modu aç.");
        info.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(info);

        autoSwitch = new Switch(this);
        autoSwitch.setText("Otomatik mod (USB takılınca paylaş)");
        autoSwitch.setTextSize(16);
        autoSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                if (updating) {
                    return;
                }
                TetherHelper.prefs(MainActivity.this).edit().putBoolean(TetherHelper.KEY_AUTO, checked).apply();
                if (checked) {
                    TetherService.start(MainActivity.this);
                } else {
                    TetherService.stop(MainActivity.this);
                }
                refresh();
            }
        });
        root.addView(autoSwitch);

        root.addView(button("1) Sistem ayarlarını değiştirme iznini ver", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:" + getPackageName())));
                } catch (Throwable t) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            }
        }));

        root.addView(button("2) Erişilebilirlik ayarlarını aç (yedek yöntem)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }));

        root.addView(button("Şimdi dene (USB takılıyken)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String r = TetherHelper.enable(MainActivity.this);
                status.setText(r);
            }
        }));

        status = new TextView(this);
        status.setPadding(0, pad, 0, 0);
        root.addView(status);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        updating = true;
        boolean auto = TetherHelper.prefs(this).getBoolean(TetherHelper.KEY_AUTO, false);
        autoSwitch.setChecked(auto);
        updating = false;

        boolean canWrite = Settings.System.canWrite(this);
        boolean accOn = TetherAccessibilityService.instance != null;
        String log = TetherHelper.prefs(this).getString(TetherHelper.KEY_LOG, "(henüz deneme yok)");

        status.setText("Sistem ayarlarını değiştirme izni: " + (canWrite ? "VAR" : "YOK")
                + "\nErişilebilirlik servisi: " + (accOn ? "AÇIK" : "KAPALI")
                + "\nOtomatik mod: " + (auto ? "AÇIK" : "KAPALI")
                + "\n\nSon durum: " + log);
    }
}
