package com.usbnet.auto;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/** USB kablo takılınca otomatik internet paylaşımını başlatan arka plan servisi. */
public class TetherService extends Service {

    private static final String USB_STATE = "android.hardware.usb.action.USB_STATE";
    private static final String CHANNEL_ID = "usbnet";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean connected = false;
    private boolean rndis = false;
    private boolean attemptScheduled = false;

    static void start(Context c) {
        Intent i = new Intent(c, TetherService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            c.startForegroundService(i);
        } else {
            c.startService(i);
        }
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, TetherService.class));
    }

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            handleUsbState(intent);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(1, buildNotification());
        Intent sticky = registerReceiver(usbReceiver, new IntentFilter(USB_STATE));
        if (sticky != null) {
            handleUsbState(sticky); // telefon zaten takılıysa hemen devreye gir
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(usbReceiver);
        } catch (Throwable ignored) {
        }
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void handleUsbState(Intent intent) {
        connected = intent.getBooleanExtra("connected", false);
        rndis = intent.getBooleanExtra("rndis", false);

        if (!connected) {
            attemptScheduled = false;
            handler.removeCallbacksAndMessages(null);
            return;
        }
        if (rndis) {
            // paylaşım zaten açık
            attemptScheduled = false;
            handler.removeCallbacksAndMessages(null);
            return;
        }
        if (!attemptScheduled) {
            attemptScheduled = true;
            handler.postDelayed(new Attempt(1), 1500); // USB bağlantısı otursun
        }
    }

    private final class Attempt implements Runnable {
        private final int n;

        Attempt(int n) {
            this.n = n;
        }

        @Override
        public void run() {
            if (!connected || rndis) {
                return;
            }
            TetherHelper.enable(getApplicationContext());
            if (n < 3) {
                handler.postDelayed(new Attempt(n + 1), 8000); // hâlâ açılmadıysa tekrar dene
            }
        }
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "USB Net Otomatik", NotificationManager.IMPORTANCE_MIN);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL_ID);
        } else {
            b = new Notification.Builder(this);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 0);
        b.setContentTitle("USB internet paylaşımı hazır")
                .setContentText("USB takılınca paylaşım otomatik açılır")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setOngoing(true);
        return b.build();
    }
}
